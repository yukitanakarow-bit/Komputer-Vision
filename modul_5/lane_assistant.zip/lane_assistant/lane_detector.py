"""
lane_detector.py
Konsep: Hough Line Transform, RANSAC lane selection, WLS fitting,
        Vanishing Point estimation, lane classification (left/right).

Langkah:
  1. Probabilistic Hough Lines pada ROI edges
  2. Klasifikasi garis → kiri / kanan berdasarkan slope
  3. RANSAC untuk memilih garis terbaik tiap sisi
  4. WLS (Weighted Least Squares) untuk averaging garis
  5. Estimasi vanishing point (intersection kiri + kanan)
  6. Extrapolasi garis ke batas bawah dan ROI atas frame
"""

import cv2
import numpy as np


class LaneDetector:
    """
    Deteksi dan seleksi jalur dari Hough lines.

    Konsep terintegrasi:
      - Hough Line Transform (Probabilistic)
      - RANSAC untuk lane selection yang robust
      - WLS (Weighted Least Squares) lane averaging
      - Vanishing Point estimation via line intersection
    """

    def __init__(self, hough_threshold=30, min_line_length=40, max_line_gap=80,
                 min_slope=0.3, ransac_iter=200, ransac_thresh=8.0):
        """
        Args:
            hough_threshold  : Minimum votes Hough
            min_line_length  : Panjang minimum segmen garis
            max_line_gap     : Gap maksimum dalam satu garis
            min_slope        : Slope minimum agar garis dianggap jalur (abaikan garis datar)
            ransac_iter      : Iterasi RANSAC
            ransac_thresh    : Jarak inlier RANSAC (piksel)
        """
        self.hough_threshold  = hough_threshold
        self.min_line_length  = min_line_length
        self.max_line_gap     = max_line_gap
        self.min_slope        = min_slope
        self.ransac_iter      = ransac_iter
        self.ransac_thresh    = ransac_thresh

    # ── Hough Lines ───────────────────────────────────────────────────────────
    def detect_hough_lines(self, roi_edges):
        """
        Probabilistic Hough Line Transform.

        Konsep Hough:
          Setiap piksel tepi memberikan "vote" pada parameter (rho, theta).
          Akumulasi vote membentuk puncak = kandidat garis.

        Returns:
            lines: array (N, 4) [x1,y1,x2,y2] atau array kosong
        """
        lines = cv2.HoughLinesP(
            roi_edges,
            rho=1,
            theta=np.deg2rad(1),
            threshold=self.hough_threshold,
            minLineLength=self.min_line_length,
            maxLineGap=self.max_line_gap,
        )
        if lines is None:
            return np.empty((0, 4), dtype=int)
        return lines.reshape(-1, 4)

    # ── Klasifikasi kiri/kanan ────────────────────────────────────────────────
    def _slope_intercept(self, x1, y1, x2, y2):
        """Hitung slope dan intercept segmen garis."""
        dx = x2 - x1
        if abs(dx) < 1e-6:
            return None, None
        slope = (y2 - y1) / dx
        intercept = y1 - slope * x1
        return slope, intercept

    def classify_lines(self, lines, frame_width):
        """
        Pisahkan garis Hough menjadi kelompok kiri dan kanan.

        Garis kiri : slope negatif (dalam koordinat gambar, y bertambah ke bawah)
        Garis kanan: slope positif
        Filter: abaikan garis terlalu datar (|slope| < min_slope)

        Args:
            lines       : array (N, 4)
            frame_width : Lebar frame

        Returns:
            left_lines, right_lines: list segmen garis
        """
        left_lines, right_lines = [], []
        cx = frame_width / 2

        for x1, y1, x2, y2 in lines:
            slope, _ = self._slope_intercept(x1, y1, x2, y2)
            if slope is None or abs(slope) < self.min_slope:
                continue
            mid_x = (x1 + x2) / 2
            if slope < 0 and mid_x < cx:
                left_lines.append([x1, y1, x2, y2])
            elif slope > 0 and mid_x > cx:
                right_lines.append([x1, y1, x2, y2])

        return np.array(left_lines), np.array(right_lines)

    # ── RANSAC Lane Selection ─────────────────────────────────────────────────
    def ransac_select_lane(self, lines):
        """
        Pilih garis jalur terbaik dari kandidat menggunakan RANSAC.

        Konsep RANSAC:
          1. Sample 1 garis secara acak sebagai hipotesis
          2. Hitung berapa garis lain yang "inlier" (slope mirip)
          3. Ulangi, simpan hipotesis dengan inlier terbanyak
          4. Rata-rata parameter dari semua inlier

        Args:
            lines: array (N, 4)

        Returns:
            (slope, intercept) garis terpilih atau None
        """
        if len(lines) == 0:
            return None

        slopes, intercepts = [], []
        for x1, y1, x2, y2 in lines:
            s, i = self._slope_intercept(x1, y1, x2, y2)
            if s is not None:
                slopes.append(s)
                intercepts.append(i)

        if not slopes:
            return None

        slopes     = np.array(slopes)
        intercepts = np.array(intercepts)
        np.random.seed(42)

        best_slope, best_inliers = None, []

        for _ in range(self.ransac_iter):
            idx = np.random.randint(len(slopes))
            hypo_slope = slopes[idx]
            # Inlier: garis dengan slope tidak terlalu berbeda
            diffs = np.abs(slopes - hypo_slope)
            inliers = np.where(diffs < self.ransac_thresh * 0.05)[0]
            if len(inliers) > len(best_inliers):
                best_inliers = inliers
                best_slope   = hypo_slope

        if best_slope is None or len(best_inliers) == 0:
            best_inliers = np.arange(len(slopes))

        return (np.mean(slopes[best_inliers]),
                np.mean(intercepts[best_inliers]))

    # ── WLS Lane Averaging ────────────────────────────────────────────────────
    def wls_average_lane(self, lines):
        """
        Weighted Least Squares averaging parameter garis jalur.

        Konsep WLS:
          β = (X'WX)^-1 X'Wy
          Bobot = panjang segmen garis (garis panjang lebih dipercaya).

        Args:
            lines: array (N, 4)

        Returns:
            (slope, intercept) atau None
        """
        if len(lines) == 0:
            return None

        slopes, intercepts, weights = [], [], []
        for x1, y1, x2, y2 in lines:
            s, i = self._slope_intercept(x1, y1, x2, y2)
            if s is not None:
                length = np.hypot(x2 - x1, y2 - y1)
                slopes.append(s)
                intercepts.append(i)
                weights.append(length)

        if not slopes:
            return None

        slopes     = np.array(slopes)
        intercepts = np.array(intercepts)
        weights    = np.array(weights)
        total_w    = weights.sum() + 1e-10

        return (np.sum(weights * slopes) / total_w,
                np.sum(weights * intercepts) / total_w)

    # ── Extrapolasi garis jalur ───────────────────────────────────────────────
    def extrapolate_lane(self, slope, intercept, y_bottom, y_top):
        """
        Ekstrapolasi garis jalur dari y_bottom ke y_top.

        x = (y - intercept) / slope

        Returns:
            (x1, y_bottom, x2, y_top) atau None
        """
        if slope is None or abs(slope) < 1e-6:
            return None
        try:
            x1 = int((y_bottom - intercept) / slope)
            x2 = int((y_top    - intercept) / slope)
            return (x1, int(y_bottom), x2, int(y_top))
        except (ZeroDivisionError, OverflowError, ValueError):
            return None

    # ── Vanishing Point ───────────────────────────────────────────────────────
    def estimate_vanishing_point(self, left_lane, right_lane):
        """
        Estimasi vanishing point = titik perpotongan jalur kiri dan kanan.

        Konsep geometri perspektif:
          Garis paralel bertemu di titik tak hingga (vanishing point).
          Dalam gambar, titik ini merepresentasikan arah pandang ke depan.

        Implementasi: selesaikan sistem 2 persamaan linear
          y = s_L * x + i_L
          y = s_R * x + i_R
          → x_vp = (i_R - i_L) / (s_L - s_R)

        Args:
            left_lane  : (slope, intercept) jalur kiri
            right_lane : (slope, intercept) jalur kanan

        Returns:
            (vx, vy) vanishing point atau None
        """
        if left_lane is None or right_lane is None:
            return None
        s_L, i_L = left_lane
        s_R, i_R = right_lane
        denom = s_L - s_R
        if abs(denom) < 1e-6:
            return None
        vx = (i_R - i_L) / denom
        vy = s_L * vx + i_L
        return (int(round(vx)), int(round(vy)))

    # ── Pipeline deteksi jalur ────────────────────────────────────────────────
    def detect(self, roi_edges, frame_shape):
        """
        Pipeline lengkap deteksi jalur.

        Returns:
            dict {
              'all_lines'    : semua garis Hough,
              'left_raw'     : garis kiri sebelum RANSAC,
              'right_raw'    : garis kanan sebelum RANSAC,
              'left_ransac'  : (slope, intercept) RANSAC kiri,
              'right_ransac' : (slope, intercept) RANSAC kanan,
              'left_wls'     : (slope, intercept) WLS kiri,
              'right_wls'    : (slope, intercept) WLS kanan,
              'vanishing_pt' : (vx, vy),
            }
        """
        h, w = frame_shape[:2]
        lines     = self.detect_hough_lines(roi_edges)
        left_raw, right_raw = self.classify_lines(lines, w)

        left_ransac  = self.ransac_select_lane(left_raw)
        right_ransac = self.ransac_select_lane(right_raw)

        left_wls     = self.wls_average_lane(left_raw)
        right_wls    = self.wls_average_lane(right_raw)

        vp = self.estimate_vanishing_point(left_wls, right_wls)

        return {
            'all_lines'    : lines,
            'left_raw'     : left_raw,
            'right_raw'    : right_raw,
            'left_ransac'  : left_ransac,
            'right_ransac' : right_ransac,
            'left_wls'     : left_wls,
            'right_wls'    : right_wls,
            'vanishing_pt' : vp,
        }
