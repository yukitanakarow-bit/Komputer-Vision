"""
deviation_analyzer.py
Konsep: Deviasi dari center, TLS fitting trajectory, Regularization (Ridge/Lasso),
        Cross-Validation, Optical Flow lane tracking.

Modul ini:
  1. Hitung deviasi posisi kendaraan dari center jalur
  2. TLS fitting untuk estimasi garis tengah yang lebih akurat
  3. Optical Flow untuk tracking pergerakan jalur antar frame
  4. Ridge/Lasso regularization untuk smoothing trajectory
  5. K-Fold CV untuk evaluasi model trajectory
  6. Alert level berdasarkan deviasi
"""

import cv2
import numpy as np
from sklearn.linear_model import Ridge, Lasso
from sklearn.model_selection import KFold
import warnings
warnings.filterwarnings('ignore')


class DeviationAnalyzer:
    """
    Analisis deviasi kendaraan dari center jalur.

    Konsep terintegrasi:
      - Deviasi dari center lane
      - TLS (Total Least Squares) center line fitting
      - Optical Flow (Lucas-Kanade) untuk lane tracking
      - Ridge/Lasso regularization untuk trajectory smoothing
      - K-Fold Cross Validation untuk model evaluation
    """

    # Alert threshold (% dari lebar frame)
    ALERT_MILD     = 0.05   # 5%  → kuning
    ALERT_MODERATE = 0.12   # 12% → oranye
    ALERT_DANGER   = 0.20   # 20% → merah

    def __init__(self, smooth_alpha=0.3, ridge_alpha=1.0):
        """
        Args:
            smooth_alpha : EMA smoothing factor untuk deviasi (0=sangat smooth)
            ridge_alpha  : Regularization strength Ridge regression
        """
        self.smooth_alpha  = smooth_alpha
        self.ridge_alpha   = ridge_alpha
        self._prev_dev     = 0.0
        self._deviation_history = []
        # Untuk optical flow
        self._prev_gray    = None
        self._prev_points  = None

    # ── Deviasi dari center ───────────────────────────────────────────────────
    def compute_deviation(self, left_lane, right_lane, frame_shape):
        """
        Hitung deviasi kendaraan dari center jalur.

        Definisi:
          center_lane  = rata-rata x jalur kiri dan kanan di bawah frame
          center_frame = x = frame_width / 2
          deviasi      = center_frame - center_lane
                         (+) = kendaraan ke kiri dari center
                         (-) = kendaraan ke kanan dari center

        Args:
            left_lane  : (slope, intercept) jalur kiri, atau None
            right_lane : (slope, intercept) jalur kanan, atau None
            frame_shape: (h, w)

        Returns:
            deviation_px    : deviasi dalam piksel
            deviation_ratio : deviasi sebagai rasio lebar frame [-1, 1]
            x_left, x_right : posisi jalur di bawah frame
        """
        h, w = frame_shape[:2]
        y_bot = h - 1

        x_left  = int((y_bot - left_lane[1])  / left_lane[0])  if left_lane  else None
        x_right = int((y_bot - right_lane[1]) / right_lane[0]) if right_lane else None

        if x_left is not None and x_right is not None:
            center_lane  = (x_left + x_right) / 2
        elif x_left is not None:
            center_lane  = x_left + w * 0.35
        elif x_right is not None:
            center_lane  = x_right - w * 0.35
        else:
            return 0.0, 0.0, None, None

        center_frame  = w / 2
        deviation_px  = center_frame - center_lane
        deviation_ratio = deviation_px / (w / 2)
        deviation_ratio = float(np.clip(deviation_ratio, -1.0, 1.0))

        # EMA smoothing
        smoothed = self.smooth_alpha * deviation_ratio + (1 - self.smooth_alpha) * self._prev_dev
        self._prev_dev = smoothed
        self._deviation_history.append(smoothed)

        return smoothed * (w / 2), smoothed, x_left, x_right

    def get_alert_level(self, deviation_ratio):
        """
        Tentukan alert level berdasarkan deviasi.

        Returns:
            level: 'OK' | 'MILD' | 'MODERATE' | 'DANGER'
            color: BGR warna untuk visualisasi
        """
        dev = abs(deviation_ratio)
        if dev < self.ALERT_MILD:
            return 'OK',       (0, 200, 0)
        elif dev < self.ALERT_MODERATE:
            return 'MILD',     (0, 200, 200)
        elif dev < self.ALERT_DANGER:
            return 'MODERATE', (0, 140, 255)
        else:
            return 'DANGER',   (0, 0, 255)

    # ── TLS Center Line Fitting ───────────────────────────────────────────────
    def tls_fit_centerline(self, left_lane, right_lane, frame_shape):
        """
        Total Least Squares fitting garis tengah dari jalur kiri + kanan.

        Konsep TLS:
          Berbeda dengan OLS (minimasi residual vertikal),
          TLS meminimalkan jarak orthogonal (tegak lurus) dari titik ke garis.
          Diselesaikan via SVD dari matriks data yang dicentrasi.

          Data: sampel titik-titik dari garis kiri & kanan
          Output: garis tengah yang optimal secara TLS

        Returns:
            (slope, intercept) garis tengah, atau None
        """
        h, w = frame_shape[:2]
        y_samples = np.linspace(int(h * 0.55), h - 1, 20)
        pts = []

        for y in y_samples:
            xl = (y - left_lane[1])  / left_lane[0]  if left_lane  else None
            xr = (y - right_lane[1]) / right_lane[0] if right_lane else None
            if xl is not None and xr is not None:
                pts.append([(xl + xr) / 2, y])
            elif xl is not None:
                pts.append([xl + w * 0.35, y])
            elif xr is not None:
                pts.append([xr - w * 0.35, y])

        if len(pts) < 4:
            return None

        pts = np.array(pts, dtype=np.float64)
        # TLS via SVD
        centered = pts - pts.mean(axis=0)
        _, _, Vt = np.linalg.svd(centered)
        direction = Vt[0]   # arah terkuat (bukan normal)
        if abs(direction[0]) < 1e-8:
            return None
        slope     = direction[1] / direction[0]
        mean_point = pts.mean(axis=0)
        intercept = mean_point[1] - slope * mean_point[0]
        return slope, intercept

    # ── Optical Flow Lane Tracking ────────────────────────────────────────────
    def optical_flow_track(self, frame, left_lane, right_lane, frame_shape):
        """
        Lucas-Kanade Optical Flow untuk tracking titik-titik jalur.

        Konsep Optical Flow:
          Estimasi pergerakan piksel antar dua frame berturutan.
          Lucas-Kanade: asumsi pergerakan kecil, menyelesaikan sistem
          persamaan dalam window lokal di sekitar setiap titik.

          Di sini, titik-titik pada jalur di-track untuk mendeteksi
          apakah jalur bergerak signifikan (akibat perubahan adegan).

        Returns:
            dict {'flow_points': pts, 'motion_mag': float}
        """
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        h, w = frame_shape[:2]

        # Buat titik-titik tracking pada posisi jalur
        track_pts = []
        y_levels = np.linspace(int(h * 0.6), h - 20, 5).astype(int)
        for y in y_levels:
            if left_lane:
                xl = (y - left_lane[1]) / left_lane[0]
                if 0 < xl < w:
                    track_pts.append([xl, float(y)])
            if right_lane:
                xr = (y - right_lane[1]) / right_lane[0]
                if 0 < xr < w:
                    track_pts.append([xr, float(y)])

        motion_mag = 0.0
        if self._prev_gray is not None and self._prev_points is not None and len(track_pts) > 0:
            curr_pts = np.array(track_pts, dtype=np.float32).reshape(-1, 1, 2)
            prev_pts = self._prev_points

            if len(prev_pts) > 0:
                next_pts, status, _ = cv2.calcOpticalFlowPyrLK(
                    self._prev_gray, gray, prev_pts, None,
                    winSize=(15, 15), maxLevel=2,
                    criteria=(cv2.TERM_CRITERIA_EPS | cv2.TERM_CRITERIA_COUNT, 10, 0.03)
                )
                if next_pts is not None and status is not None:
                    good = status.flatten() == 1
                    if good.sum() > 0:
                        diffs = next_pts[good] - prev_pts[good]
                        motion_mag = float(np.mean(np.linalg.norm(diffs.reshape(-1, 2), axis=1)))

        self._prev_gray   = gray.copy()
        self._prev_points = np.array(track_pts, dtype=np.float32).reshape(-1, 1, 2) if track_pts else np.empty((0, 1, 2), np.float32)

        return {'flow_points': track_pts, 'motion_mag': motion_mag}

    # ── Ridge/Lasso Trajectory Smoothing ─────────────────────────────────────
    def smooth_trajectory_ridge(self, deviations, alpha=None):
        """
        Smooth trajectory deviasi menggunakan Ridge regression (L2 regularization).

        Konsep Ridge:
          Meminimalkan: Σ(yᵢ - ŷᵢ)² + α·Σβⱼ²
          Regularisasi L2 mencegah overfitting → trajectory lebih halus.

        Args:
            deviations: list nilai deviasi historis
            alpha     : strength regularisasi (None = gunakan self.ridge_alpha)

        Returns:
            smoothed_deviations: array trajectory yang diperhalus
        """
        if len(deviations) < 3:
            return np.array(deviations)

        alpha = alpha or self.ridge_alpha
        devs  = np.array(deviations)
        t     = np.arange(len(devs)).reshape(-1, 1)
        model = Ridge(alpha=alpha)
        model.fit(t, devs)
        return model.predict(t)

    def smooth_trajectory_lasso(self, deviations, alpha=0.01):
        """
        Smooth trajectory deviasi menggunakan Lasso regression (L1 regularization).

        Konsep Lasso:
          Meminimalkan: Σ(yᵢ - ŷᵢ)² + α·Σ|βⱼ|
          L1 regularisasi menghasilkan solusi sparse (beberapa β = 0).
          Berguna untuk menghilangkan spike/noise pada trajectory.
        """
        if len(deviations) < 3:
            return np.array(deviations)

        devs  = np.array(deviations)
        t     = np.arange(len(devs)).reshape(-1, 1)
        model = Lasso(alpha=alpha, max_iter=5000)
        model.fit(t, devs)
        return model.predict(t)

    # ── K-Fold Cross Validation ───────────────────────────────────────────────
    def evaluate_smoothing_cv(self, deviations, k=5):
        """
        Bandingkan Ridge vs Lasso menggunakan K-Fold CV.

        Konsep K-Fold CV:
          1. Bagi data menjadi K bagian
          2. Latih pada K-1, validasi pada 1 bagian
          3. Ulangi K kali → rata-rata MSE sebagai metrik

        Returns:
            dict {'ridge': {'mse': float}, 'lasso': {'mse': float}}
        """
        if len(deviations) < k + 1:
            return {}

        devs = np.array(deviations)
        t    = np.arange(len(devs)).reshape(-1, 1)
        kf   = KFold(n_splits=k, shuffle=False)
        results = {}

        for name, model in [('Ridge (L2)', Ridge(alpha=self.ridge_alpha)),
                             ('Lasso (L1)', Lasso(alpha=0.01, max_iter=5000))]:
            mses = []
            for tr_idx, va_idx in kf.split(t):
                model.fit(t[tr_idx], devs[tr_idx])
                pred = model.predict(t[va_idx])
                mses.append(np.mean((devs[va_idx] - pred)**2))
            results[name] = {
                'mean_mse': float(np.mean(mses)),
                'std_mse':  float(np.std(mses)),
            }
        return results

    def get_deviation_history(self):
        """Kembalikan riwayat deviasi."""
        return list(self._deviation_history)

    def reset(self):
        """Reset state (untuk gambar baru)."""
        self._prev_dev           = 0.0
        self._deviation_history  = []
        self._prev_gray          = None
        self._prev_points        = None
