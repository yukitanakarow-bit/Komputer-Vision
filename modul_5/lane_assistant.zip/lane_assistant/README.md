# Lane Keeping Assistant Simulator
**Proyek Modul 5 — Soal 4: Lane Keeping Assistant Simulator**

---

## Konsep yang Diintegrasikan (15/20)

| # | Konsep | Modul |
|---|--------|-------|
| 1 | Preprocessing — CLAHE, Gaussian Blur | `preprocessor.py` |
| 2 | Edge Detection — Canny + ROI mask | `preprocessor.py` |
| 3 | OLS — Ordinary Least Squares | `preprocessor.py`, `fitting_comparator.py` |
| 4 | Hough Line Transform (Probabilistic) | `lane_detector.py` |
| 5 | RANSAC — lane selection | `lane_detector.py`, `fitting_comparator.py` |
| 6 | WLS — Weighted Least Squares averaging | `lane_detector.py`, `fitting_comparator.py` |
| 7 | Vanishing Point — intersection analysis | `lane_detector.py` |
| 8 | Lane Overlay — markers, fill polygon | `visualizer.py` |
| 9 | TLS — Total Least Squares center line | `deviation_analyzer.py`, `fitting_comparator.py` |
| 10 | Optical Flow — Lucas-Kanade tracking | `deviation_analyzer.py` |
| 11 | Deviasi dari center + EMA smoothing | `deviation_analyzer.py` |
| 12 | Ridge (L2) + Lasso (L1) Regularization | `deviation_analyzer.py`, `fitting_comparator.py` |
| 13 | K-Fold Cross Validation | `deviation_analyzer.py`, `fitting_comparator.py` |
| 14 | Denoising Benchmark — NLM/Bilateral/Gaussian/Median + PSNR | `visualizer.py` |
| 15 | Template Matching (marka jalan) + Contour Fitting | `visualizer.py` |

---

## Struktur Folder

```
lane_assistant/
  main.py                   ← Entry point
  lane_pipeline.py          ← Pipeline utama (integrasi semua modul)
  preprocessor.py           ← Preprocessing + Canny + OLS + ROI
  lane_detector.py          ← Hough + RANSAC + WLS + Vanishing Point
  deviation_analyzer.py     ← Deviasi + TLS + Optical Flow + Ridge/Lasso + CV
  visualizer.py             ← Overlay + Denoising + Template Matching + Contour
  fitting_comparator.py     ← OLS/WLS/TLS/RANSAC/Ridge/Lasso + K-Fold CV
  utils/
    image_utils.py
    viz_utils.py
  data/
    input/                  ← Taruh foto jalan di sini
    output/
  results/                  ← Output tersimpan otomatis
  tests/
    test_all.py
  requirements.txt
  README.md
```

---

## Instalasi

```bash
pip install -r requirements.txt
```

---

## Cara Pakai

### Demo otomatis (5 skenario jalan sintetis)
```bash
python main.py
```

### Analisis satu gambar
```bash
python main.py --input foto_jalan.jpg
```

### Batch seluruh folder
```bash
python main.py --input data/input/
```

### Semua analisis sekaligus
```bash
python main.py --input foto.jpg --all
```

### Opsi terpisah
```bash
python main.py --input foto.jpg --bench    # denoising benchmark
python main.py --input foto.jpg --fitting  # fitting comparator dashboard
```

### Unit test
```bash
python tests/test_all.py
```

---

## Konfigurasi

Edit `CONFIG` di `main.py`:

```python
CONFIG = {
    'canny_lo':       50,    # Threshold bawah Canny
    'canny_hi':      150,    # Threshold atas Canny
    'roi_top_ratio': 0.55,   # Batas atas ROI (lebih kecil = area lebih luas)
    'hough_threshold': 30,   # Minimum votes Hough
    'min_line_length': 40,   # Panjang minimum segmen garis
    'min_slope':       0.3,  # Filter garis terlalu datar
    'smooth_alpha':    0.3,  # Smoothing deviasi (kecil = lebih halus)
    'ridge_alpha':     1.0,  # Regularization Ridge
    'alpha_fill':      0.25, # Transparansi fill jalur
}
```

---

## Output yang Dihasilkan

| File | Keterangan |
|------|------------|
| `results/<nama>_pipeline.png` | Visualisasi 8 langkah pipeline |
| `results/<nama>_result.jpg` | Frame dengan overlay lengkap |
| `results/<nama>_denoising.png` | Benchmark NLM vs Bilateral vs Gaussian vs Median |
| `results/<nama>_fitting.png` | Dashboard OLS/WLS/TLS/RANSAC + CV |

---

## Alert Level

| Level | Deviasi | Warna |
|-------|---------|-------|
| OK | < 5% | Hijau |
| MILD | 5–12% | Kuning |
| MODERATE | 12–20% | Oranye |
| DANGER | > 20% | Merah + Banner |

---

## Tips

- Untuk hasil terbaik, gunakan gambar dengan **jalan lurus** dan **kontras marka jalan tinggi**
- Jika deteksi jalur kurang akurat, coba naikkan `roi_top_ratio` (0.45–0.65)
- Sesuaikan `canny_lo`/`canny_hi` tergantung kondisi pencahayaan gambar
- Mode demo sintetis langsung bisa dijalankan tanpa foto
