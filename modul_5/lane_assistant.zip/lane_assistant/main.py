"""
main.py — Lane Keeping Assistant Simulator (Modul 5, Soal 4)

Cara pakai:
  python main.py                         # demo sintetis semua fitur
  python main.py --input foto.jpg        # analisis satu gambar
  python main.py --input folder/         # batch semua gambar dalam folder
  python main.py --input foto.jpg --all  # aktifkan semua analisis (denoising + fitting)
  python main.py --input foto.jpg --bench  # denoising benchmark saja
  python main.py --input foto.jpg --fitting # fitting comparator saja
"""

import cv2
import numpy as np
import argparse
import os

from lane_pipeline     import LaneAssistantPipeline
from utils.image_utils import ensure_dir, save_image

# ── KONFIGURASI ───────────────────────────────────────────────────────────────
# Ubah parameter di sini tanpa menyentuh kode modul.
CONFIG = {
    # Preprocessing
    'blur_ksize':    5,
    'canny_lo':      50,
    'canny_hi':      150,
    'clahe_clip':    2.0,
    'roi_top_ratio': 0.55,   # Batas atas ROI (0.0 = atas gambar, 1.0 = bawah)

    # Hough Lines
    'hough_threshold':  30,
    'min_line_length':  40,
    'max_line_gap':     80,
    'min_slope':        0.3,

    # Deviation & Smoothing
    'smooth_alpha':  0.3,    # EMA smoothing (lebih kecil = lebih smooth)
    'ridge_alpha':   1.0,    # Regularization strength Ridge

    # Rendering
    'alpha_fill':    0.25,   # Transparansi lane fill

    # I/O
    'results_dir':  'results',
}
# ─────────────────────────────────────────────────────────────────────────────


def make_demo_road(width=1280, height=720, curve=0.0, offset=0.0,
                   lane_style='solid', noise=30):
    """
    Buat gambar jalan sintetis yang realistis untuk demo.

    Args:
        width, height : Ukuran frame
        curve         : Kelengkungan jalur (-1 ke kiri, +1 ke kanan)
        offset        : Offset posisi kendaraan dari center (-1 ke kiri, +1 ke kanan)
        lane_style    : 'solid' | 'dashed' | 'both'
        noise         : Level noise gambar
    """
    np.random.seed(42)

    # Background aspal
    img = np.ones((height, width, 3), dtype=np.uint8) * 70
    # Tambah tekstur aspal
    for _ in range(2000):
        x, y = np.random.randint(0, width), np.random.randint(0, height)
        v = np.random.randint(55, 85)
        img[y, x] = (v, v, v)

    # Parameter perspektif jalur
    cx         = width  // 2 + int(offset * width * 0.15)
    vp_y       = int(height * 0.42)    # y vanishing point
    vp_x       = int(cx + curve * 60)  # vanishing point (sedikit ke kanan/kiri)

    # Lebar jalur di bawah dan di atas (perspektif)
    lane_w_bot = int(width * 0.38)
    lane_w_top = int(width * 0.04)

    # Koordinat jalur kiri dan kanan
    pts_left  = []
    pts_right = []

    for frac in np.linspace(0, 1, 40):
        y    = int(vp_y + frac * (height - vp_y))
        lw   = int(lane_w_top + frac * (lane_w_bot - lane_w_top))
        vp_x_at_y = int(vp_x + curve * frac * 30)
        xl   = vp_x_at_y - lw
        xr   = vp_x_at_y + lw
        pts_left.append( (xl, y))
        pts_right.append((xr, y))

    # Gambar aspal area jalur (sedikit lebih terang)
    road_pts = np.array(pts_left + pts_right[::-1], dtype=np.int32)
    cv2.fillPoly(img, [road_pts], (85, 85, 85))

    # Gambar marka tengah (putus-putus kuning)
    for i in range(0, len(pts_left) - 1, 3):
        if i % 6 < 3:
            x1 = (pts_left[i][0]   + pts_right[i][0])   // 2
            x2 = (pts_left[i+1][0] + pts_right[i+1][0]) // 2
            cv2.line(img, (x1, pts_left[i][1]), (x2, pts_left[i+1][1]), (0, 200, 200), 2)

    # Gambar garis jalur kiri
    for i in range(len(pts_left) - 1):
        pt1, pt2 = pts_left[i], pts_left[i+1]
        if lane_style in ('solid', 'both'):
            cv2.line(img, pt1, pt2, (200, 200, 200), 3)
        elif lane_style == 'dashed' and i % 4 < 2:
            cv2.line(img, pt1, pt2, (200, 200, 200), 3)

    # Gambar garis jalur kanan
    for i in range(len(pts_right) - 1):
        pt1, pt2 = pts_right[i], pts_right[i+1]
        if lane_style in ('solid', 'both'):
            cv2.line(img, pt1, pt2, (200, 200, 200), 3)
        elif lane_style == 'dashed' and i % 4 < 2:
            cv2.line(img, pt1, pt2, (200, 200, 200), 3)

    # Tambah elemen realistis (pohon / pagar samping)
    for side in [0, width]:
        for y_tree in range(0, int(height * 0.45), 40):
            x_tree = side + np.random.randint(-20, 20)
            cv2.rectangle(img, (x_tree - 3, y_tree), (x_tree + 3, y_tree + 30), (30, 60, 20), -1)
            cv2.circle(img, (x_tree, y_tree), 12, (30, 100, 30), -1)

    # Sky gradient (atas)
    for y in range(int(height * 0.3)):
        alpha = y / (height * 0.3)
        color = (int(150 * alpha + 30 * (1-alpha)),
                 int(180 * alpha + 50 * (1-alpha)),
                 int(220 * alpha + 80 * (1-alpha)))
        img[y, :] = color

    # Noise
    if noise > 0:
        n = np.random.normal(0, noise, img.shape).astype(np.int16)
        img = np.clip(img.astype(np.int16) + n, 0, 255).astype(np.uint8)

    return img


def run_demo():
    """Demo lengkap dengan berbagai kondisi jalan sintetis."""
    print("\n╔══════════════════════════════════════════════════════╗")
    print("║     Lane Keeping Assistant Simulator — Demo          ║")
    print("╚══════════════════════════════════════════════════════╝")

    ensure_dir('data/input')
    ensure_dir('results')

    # Berbagai skenario
    scenarios = [
        ('lurus_center',  0.0,   0.0,  'solid',  20),
        ('lurus_kiri',    0.0,  -0.4,  'solid',  25),
        ('lurus_kanan',   0.0,   0.4,  'solid',  25),
        ('tikungan',      0.5,   0.1,  'both',   30),
        ('hujan',         0.0,   0.0,  'dashed', 40),
    ]

    pipeline = LaneAssistantPipeline(config=CONFIG)

    for name, curve, offset, style, noise in scenarios:
        print(f"\n{'='*60}")
        print(f"  Skenario: {name}  (kurva={curve}, offset={offset})")
        frame = make_demo_road(curve=curve, offset=offset, lane_style=style, noise=noise)
        save_image(frame, f'data/input/{name}.jpg')

        pipeline.analyze(
            frame,
            show_viz       = True,
            save_results   = True,
            run_denoising  = (name == 'lurus_center'),
            run_fitting    = (name == 'lurus_center'),
        )

    print("\n✓ Demo selesai. Hasil tersimpan di folder 'results/'.\n")


def main():
    parser = argparse.ArgumentParser(description='Lane Keeping Assistant — Modul 5')
    parser.add_argument('--input',   type=str, default=None,
                        help='Path gambar / folder. Tanpa argumen = demo sintetis.')
    parser.add_argument('--bench',   action='store_true', help='Denoising benchmark')
    parser.add_argument('--fitting', action='store_true', help='Fitting comparator dashboard')
    parser.add_argument('--all',     action='store_true', help='Aktifkan semua analisis')
    args = parser.parse_args()

    if args.all:
        args.bench = args.fitting = True

    pipeline = LaneAssistantPipeline(config=CONFIG)
    ensure_dir('results')

    if args.input is None:
        run_demo()
    elif os.path.isdir(args.input):
        pipeline.batch_analyze(
            args.input,
            show_viz=True, save_results=True,
            run_denoising=args.bench, run_fitting=args.fitting,
        )
    else:
        pipeline.analyze(
            args.input,
            show_viz=True, save_results=True,
            run_denoising=args.bench, run_fitting=args.fitting,
        )


if __name__ == '__main__':
    main()
