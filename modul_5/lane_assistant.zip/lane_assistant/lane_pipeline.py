"""
lane_pipeline.py
Pipeline utama Lane Keeping Assistant.

Mengintegrasikan 14 konsep:
  1.  Preprocessing (CLAHE, Gaussian blur)
  2.  Edge Detection (Canny + ROI mask)
  3.  OLS — line fitting
  4.  Hough Line Transform (Probabilistic)
  5.  RANSAC — lane selection
  6.  WLS — weighted lane averaging
  7.  Vanishing Point estimation (intersection analysis)
  8.  Lane overlay (markers, polygon fill, contour segmentation)
  9.  TLS — center line fitting
  10. Optical Flow (Lucas-Kanade lane tracking)
  11. Deviasi dari center + EMA smoothing
  12. Ridge/Lasso regularization (trajectory smoothing)
  13. K-Fold Cross Validation (smoothing model evaluation)
  14. Denoising benchmark (NLM/Bilateral/Gaussian/Median) + PSNR
  +   Template matching (marka jalan)
  +   Contour fitting (segmentasi area jalur)
"""

import cv2
import numpy as np
import os
import time

from preprocessor        import Preprocessor
from lane_detector       import LaneDetector
from deviation_analyzer  import DeviationAnalyzer
from visualizer          import LaneVisualizer
from fitting_comparator  import FittingComparator
from utils.image_utils   import load_image, save_image, resize_img, ensure_dir
from utils.viz_utils     import show_pipeline


class LaneAssistantPipeline:
    """
    Pipeline Lane Keeping Assistant yang lengkap dan modular.

    Satu gambar → semua langkah pipeline → frame dengan overlay lengkap.
    """

    def __init__(self, config=None):
        cfg = config or {}
        self.prep   = Preprocessor(
            blur_ksize    = cfg.get('blur_ksize',    5),
            canny_lo      = cfg.get('canny_lo',      50),
            canny_hi      = cfg.get('canny_hi',      150),
            roi_top_ratio = cfg.get('roi_top_ratio', 0.55),
            clahe_clip    = cfg.get('clahe_clip',    2.0),
        )
        self.det    = LaneDetector(
            hough_threshold  = cfg.get('hough_threshold', 30),
            min_line_length  = cfg.get('min_line_length',  40),
            max_line_gap     = cfg.get('max_line_gap',     80),
            min_slope        = cfg.get('min_slope',       0.3),
        )
        self.dev    = DeviationAnalyzer(
            smooth_alpha  = cfg.get('smooth_alpha', 0.3),
            ridge_alpha   = cfg.get('ridge_alpha',  1.0),
        )
        self.viz    = LaneVisualizer(alpha_fill=cfg.get('alpha_fill', 0.25))
        self.fc     = FittingComparator()
        self.results_dir = cfg.get('results_dir', 'results')
        ensure_dir(self.results_dir)

    # ──────────────────────────────────────────────────────────────────────────
    def process_frame(self, frame):
        """
        Proses satu frame melalui pipeline lengkap.

        Returns:
            dict hasil semua langkah
        """
        t0 = time.perf_counter()
        h, w = frame.shape[:2]
        roi_top_y = int(h * self.prep.roi_top_ratio)

        # 1–2. Preprocessing + Edge Detection
        proc_steps = self.prep.process(frame)
        roi_edges  = list(proc_steps.values())[-1]

        # 3–7. Hough + RANSAC + WLS + Vanishing Point
        detection = self.det.detect(roi_edges, frame.shape)

        # 8–9. Deviasi + TLS center line
        left_wls  = detection.get('left_wls')
        right_wls = detection.get('right_wls')

        dev_px, dev_ratio, x_left, x_right = self.dev.compute_deviation(
            left_wls, right_wls, frame.shape)
        alert_level, alert_color = self.dev.get_alert_level(dev_ratio)

        # TLS center line (jika kedua jalur terdeteksi)
        center_tls = None
        if left_wls and right_wls:
            center_tls = self.dev.tls_fit_centerline(left_wls, right_wls, frame.shape)

        # 10. Optical flow tracking
        flow_info = self.dev.optical_flow_track(frame, left_wls, right_wls, frame.shape)

        # 11. Segmentasi kontur jalur
        left_c = right_c = None
        if left_wls:
            s, i = left_wls
            y_b, y_t = h - 1, roi_top_y
            try:
                left_c = (int((y_b-i)/s), y_b, int((y_t-i)/s), y_t)
            except: pass
        if right_wls:
            s, i = right_wls
            try:
                right_c = (int((y_b-i)/s), y_b, int((y_t-i)/s), y_t)
            except: pass
        _, road_contour = self.viz.segment_road_area(frame, left_c, right_c)

        # Info panel
        n_left  = len(detection.get('left_raw',  []))
        n_right = len(detection.get('right_raw', []))
        info = {
            'Jalur Kiri':  f"{n_left} segmen",
            'Jalur Kanan': f"{n_right} segmen",
            'Vanishing':   str(detection.get('vanishing_pt', 'N/A')),
            'Flow Mag':    f"{flow_info['motion_mag']:.1f} px",
            'Method':      'RANSAC+WLS+TLS',
        }

        # Render frame
        rendered = self.viz.render(
            frame, detection, dev_ratio,
            alert_level, alert_color, roi_top_y, info
        )

        elapsed = time.perf_counter() - t0

        return {
            'rendered'      : rendered,
            'proc_steps'    : proc_steps,
            'detection'     : detection,
            'dev_ratio'     : dev_ratio,
            'alert_level'   : alert_level,
            'alert_color'   : alert_color,
            'center_tls'    : center_tls,
            'flow_info'     : flow_info,
            'road_contour'  : road_contour,
            'time_ms'       : elapsed * 1000,
        }

    # ──────────────────────────────────────────────────────────────────────────
    def analyze(self, image_or_path, show_viz=True, save_results=True,
                run_denoising=False, run_fitting=False):
        """
        Analisis lengkap satu gambar dengan semua fitur.

        Args:
            image_or_path  : Path file atau numpy array
            show_viz       : Tampilkan visualisasi pipeline
            save_results   : Simpan output ke results/
            run_denoising  : Jalankan denoising benchmark
            run_fitting    : Tampilkan fitting comparator dashboard

        Returns:
            dict hasil
        """
        if isinstance(image_or_path, str):
            frame     = load_image(image_or_path)
            base_name = os.path.splitext(os.path.basename(image_or_path))[0]
        else:
            frame     = image_or_path.copy()
            base_name = 'frame'

        frame = resize_img(frame, max_w=1280)
        print(f"\n[ANALYZE] {base_name}  ({frame.shape[1]}x{frame.shape[0]})")

        self.dev.reset()
        result = self.process_frame(frame)

        print(f"  Alert     : {result['alert_level']}")
        print(f"  Deviasi   : {result['dev_ratio']*100:.1f}%")
        print(f"  Waktu     : {result['time_ms']:.1f} ms")

        # Visualisasi pipeline
        if show_viz:
            pipeline_steps = {
                **result['proc_steps'],
                '7. Lane Detection'  : self._draw_raw_lines(frame, result['detection']),
                '8. Final Result'    : result['rendered'],
            }
            show_pipeline(
                pipeline_steps,
                title=f"Lane Assistant Pipeline — {base_name}",
                save_path=os.path.join(self.results_dir, f'{base_name}_pipeline.png'),
                cols=4,
            )

        # Denoising benchmark
        if run_denoising:
            self.viz.denoising_benchmark(
                frame,
                save_path=os.path.join(self.results_dir, f'{base_name}_denoising.png')
            )

        # Fitting comparator
        if run_fitting:
            h, w = frame.shape[:2]
            x_data = np.linspace(0, w, 60)
            ld = result['detection']
            if ld.get('left_wls'):
                s, i = ld['left_wls']
                y_data = s * x_data + i + np.random.normal(0, 10, 60)
            else:
                y_data = 0.5 * x_data + h * 0.3 + np.random.normal(0, 10, 60)
            self.fc.compare_and_plot(
                x_data, y_data,
                title=f"Fitting Comparator — {base_name}",
                save_path=os.path.join(self.results_dir, f'{base_name}_fitting.png'),
            )

        # Simpan output
        if save_results:
            save_image(result['rendered'],
                       os.path.join(self.results_dir, f'{base_name}_result.jpg'))

        return result

    def batch_analyze(self, folder, **kwargs):
        """Proses semua gambar dalam folder."""
        exts = ('.jpg', '.jpeg', '.png', '.bmp')
        files = [f for f in sorted(os.listdir(folder)) if f.lower().endswith(exts)]
        if not files:
            print(f"[WARN] Tidak ada gambar di: {folder}")
            return []
        print(f"\n[BATCH] {len(files)} gambar dari {folder}")
        results = []
        for i, f in enumerate(files, 1):
            print(f"\n[{i}/{len(files)}]", end=' ')
            try:
                r = self.analyze(os.path.join(folder, f), **kwargs)
                results.append({'file': f, 'ok': True, 'result': r})
            except Exception as e:
                print(f"[ERROR] {f}: {e}")
                results.append({'file': f, 'ok': False})
        ok = sum(1 for r in results if r['ok'])
        print(f"\n[BATCH] {ok}/{len(files)} berhasil.")
        return results

    def _draw_raw_lines(self, frame, detection):
        """Gambar semua garis Hough mentah untuk visualisasi."""
        out = frame.copy()
        for x1, y1, x2, y2 in detection.get('all_lines', []):
            cv2.line(out, (int(x1), int(y1)), (int(x2), int(y2)), (100, 200, 100), 1)
        for x1, y1, x2, y2 in detection.get('left_raw', []):
            cv2.line(out, (int(x1), int(y1)), (int(x2), int(y2)), (50, 200, 50), 2)
        for x1, y1, x2, y2 in detection.get('right_raw', []):
            cv2.line(out, (int(x1), int(y1)), (int(x2), int(y2)), (50, 200, 255), 2)
        return out
