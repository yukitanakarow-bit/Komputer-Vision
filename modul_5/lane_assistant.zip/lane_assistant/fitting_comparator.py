"""
fitting_comparator.py
Konsep: OLS vs WLS vs TLS vs RANSAC dashboard + Ridge/Lasso + K-Fold CV.
Digunakan untuk membandingkan metode fitting pada data garis jalur.
"""

import numpy as np
import matplotlib.pyplot as plt
from sklearn.linear_model import Ridge, Lasso
from sklearn.model_selection import KFold
import os
import warnings
warnings.filterwarnings('ignore')


class FittingComparator:
    """
    Dashboard perbandingan semua metode fitting.

    Konsep terintegrasi:
      - OLS, WLS, TLS, RANSAC
      - Ridge (L2) dan Lasso (L1) regularization
      - K-Fold Cross Validation
    """

    def __init__(self, ransac_thresh=0.15, cv_folds=5):
        self.ransac_thresh = ransac_thresh
        self.cv_folds      = cv_folds

    def ols(self, x, y):
        """OLS: β = (X'X)^-1 X'y"""
        X = np.column_stack([x, np.ones_like(x)])
        b, _, _, _ = np.linalg.lstsq(X, y, rcond=None)
        return b

    def wls(self, x, y, w=None):
        """WLS: β = (X'WX)^-1 X'Wy — bobot default = 1/distance dari mean."""
        if w is None:
            d = np.abs(x - x.mean())
            w = d / (d.max() + 1e-10) + 0.1
        W = np.diag(w)
        X = np.column_stack([x, np.ones_like(x)])
        try:
            b = np.linalg.inv(X.T @ W @ X) @ X.T @ W @ y
        except np.linalg.LinAlgError:
            b = self.ols(x, y)
        return b

    def tls(self, x, y):
        """TLS via SVD — meminimalkan jarak orthogonal ke garis."""
        data = np.column_stack([x - x.mean(), y - y.mean()])
        _, _, Vt = np.linalg.svd(data)
        n = Vt[-1]
        if abs(n[0]) < 1e-10:
            return np.array([1e10, x.mean()])
        s = -n[1] / n[0]
        i = y.mean() - s * x.mean()
        return np.array([s, i])

    def ransac(self, x, y, n_iter=400):
        """RANSAC: pilih garis terbaik yang meminimalkan outlier."""
        np.random.seed(42)
        best_b, best_n = None, 0
        pts = np.column_stack([x, y])
        for _ in range(n_iter):
            idx = np.random.choice(len(pts), 2, replace=False)
            p1, p2 = pts[idx]
            if abs(p2[0] - p1[0]) < 1e-10:
                continue
            s = (p2[1] - p1[1]) / (p2[0] - p1[0])
            b_i = p1[1] - s * p1[0]
            inl = np.sum(np.abs(y - (s*x + b_i)) < self.ransac_thresh * np.std(y))
            if inl > best_n:
                best_n, best_b = inl, np.array([s, b_i])
        return best_b if best_b is not None else self.ols(x, y)

    def cv_compare(self, x, y):
        """K-Fold CV untuk OLS, Ridge, Lasso."""
        X = x.reshape(-1, 1)
        kf = KFold(n_splits=self.cv_folds, shuffle=True, random_state=42)
        models = {'OLS': Ridge(alpha=1e-9), 'Ridge': Ridge(alpha=1.0), 'Lasso': Lasso(alpha=0.01, max_iter=5000)}
        out = {}
        for name, mdl in models.items():
            mses = []
            for tr, va in kf.split(X):
                mdl.fit(X[tr], y[tr])
                mses.append(np.mean((y[va] - mdl.predict(X[va]))**2))
            out[name] = {'mean': np.mean(mses), 'std': np.std(mses)}
        return out

    def compare_and_plot(self, x, y, title="Fitting Comparator", save_path=None):
        """Dashboard visualisasi semua metode + CV."""
        # Tambah outlier sintetis
        np.random.seed(7)
        n_out = max(2, len(x)//8)
        ox = np.random.choice(x, n_out)
        oy = np.random.uniform(y.min() - y.std(), y.max() + y.std(), n_out)
        xn, yn = np.concatenate([x, ox]), np.concatenate([y, oy])

        methods = {
            'OLS':    self.ols(xn, yn),
            'WLS':    self.wls(xn, yn),
            'TLS':    self.tls(xn, yn),
            'RANSAC': self.ransac(xn, yn),
        }
        colors = {'OLS':'blue','WLS':'green','TLS':'orange','RANSAC':'red'}

        fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(16, 6))

        ax1.scatter(xn, yn, c='lightgray', s=20, zorder=1, label='Data+Outlier')
        ax1.scatter(x,  y,  c='black',    s=15, zorder=2, label='Inlier')
        xp = np.linspace(x.min(), x.max(), 200)
        for nm, b in methods.items():
            if np.isfinite(b[0]) and abs(b[0]) < 1e6:
                ax1.plot(xp, b[0]*xp+b[1], color=colors[nm], lw=2.5, label=nm)
        ax1.set_title('Perbandingan Metode Fitting', fontweight='bold')
        ax1.legend(); ax1.grid(True, alpha=0.3)

        cv_res = self.cv_compare(xn, yn)
        names  = list(cv_res.keys())
        mses   = [cv_res[n]['mean'] for n in names]
        stds   = [cv_res[n]['std']  for n in names]
        bars   = ax2.bar(names, mses, yerr=stds, capsize=6,
                         color=['steelblue','coral','mediumseagreen'],
                         edgecolor='navy', alpha=0.85)
        for bar, m in zip(bars, mses):
            ax2.text(bar.get_x()+bar.get_width()/2, bar.get_height()+max(mses)*0.02,
                     f'{m:.3f}', ha='center', fontsize=10)
        ax2.set_title(f'K-Fold CV (k={self.cv_folds}) — MSE', fontweight='bold')
        ax2.set_ylabel('MSE'); ax2.grid(True, alpha=0.3, axis='y')

        plt.suptitle(title, fontsize=14, fontweight='bold')
        plt.tight_layout()
        if save_path:
            os.makedirs(os.path.dirname(save_path) if os.path.dirname(save_path) else '.', exist_ok=True)
            plt.savefig(save_path, dpi=100, bbox_inches='tight')
            print(f"[INFO] Chart disimpan: {save_path}")
        plt.show()
        return methods
