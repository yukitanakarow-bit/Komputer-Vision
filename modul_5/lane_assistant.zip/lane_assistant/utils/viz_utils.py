"""utils/viz_utils.py — Visualisasi pipeline."""
import cv2, numpy as np, matplotlib.pyplot as plt, os

def show_pipeline(steps: dict, title="Pipeline", save_path=None, cols=3):
    items = list(steps.items())
    n = len(items)
    rows = (n + cols - 1) // cols
    fig, axes = plt.subplots(rows, cols, figsize=(6*cols, 5*rows))
    axes = np.array(axes).flatten()
    for ax, (lbl, img) in zip(axes, items):
        if len(img.shape) == 2:
            ax.imshow(img, cmap='gray')
        else:
            ax.imshow(cv2.cvtColor(img, cv2.COLOR_BGR2RGB))
        ax.set_title(lbl, fontsize=11, fontweight='bold')
        ax.axis('off')
    for ax in axes[n:]:
        ax.axis('off')
    plt.suptitle(title, fontsize=14, fontweight='bold')
    plt.tight_layout()
    if save_path:
        os.makedirs(os.path.dirname(save_path) if os.path.dirname(save_path) else '.', exist_ok=True)
        plt.savefig(save_path, dpi=100, bbox_inches='tight')
        print(f"[INFO] Chart disimpan: {save_path}")
    plt.show()

def plot_chart(data: dict, xlabel, ylabel, title, save_path=None, kind='bar'):
    labels, values = list(data.keys()), list(data.values())
    fig, ax = plt.subplots(figsize=(10, 5))
    if kind == 'bar':
        bars = ax.bar(labels, values, color='steelblue', edgecolor='navy', alpha=0.85)
        for b, v in zip(bars, values):
            ax.text(b.get_x()+b.get_width()/2, b.get_height()+max(values)*0.01,
                    f'{v:.2f}', ha='center', fontsize=9)
    else:
        ax.plot(labels, values, 'o-', color='steelblue', linewidth=2)
    ax.set_xlabel(xlabel); ax.set_ylabel(ylabel); ax.set_title(title)
    ax.grid(True, alpha=0.3)
    plt.tight_layout()
    if save_path:
        os.makedirs(os.path.dirname(save_path) if os.path.dirname(save_path) else '.', exist_ok=True)
        plt.savefig(save_path, dpi=100, bbox_inches='tight')
        print(f"[INFO] Chart disimpan: {save_path}")
    plt.show()
