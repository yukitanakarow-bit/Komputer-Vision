"""utils/image_utils.py — Utilitas baca/tulis gambar."""
import cv2, os, numpy as np

def load_image(path):
    if not os.path.exists(path):
        raise FileNotFoundError(f"File tidak ditemukan: {path}")
    img = cv2.imread(path)
    if img is None:
        raise ValueError(f"Gagal membaca: {path}")
    return img

def save_image(img, path):
    os.makedirs(os.path.dirname(path) if os.path.dirname(path) else '.', exist_ok=True)
    ok = cv2.imwrite(path, img)
    if ok: print(f"[INFO] Tersimpan: {path}")
    return ok

def resize_img(img, max_w=1280):
    h, w = img.shape[:2]
    if w > max_w:
        scale = max_w / w
        return cv2.resize(img, (max_w, int(h * scale)))
    return img.copy()

def ensure_dir(path):
    os.makedirs(path, exist_ok=True)
    return path
