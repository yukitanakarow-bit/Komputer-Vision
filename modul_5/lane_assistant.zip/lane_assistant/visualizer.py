"""
visualizer.py
Konsep: Overlay lane markers, Denoising benchmark, Template matching,
        Contour fitting, Segmentasi.

Modul ini menggambar semua visualisasi output:
  1. Overlay lane lines berwarna
  2. Lane fill polygon (area aman)
  3. Vanishing point marker
  4. Deviasi meter / HUD
  5. Alert banner
  6. Denoising benchmark dengan PSNR
  7. Template matching untuk marka jalan
  8. Contour fitting segmentasi jalur
"""

import cv2
import numpy as np
import matplotlib.pyplot as plt
import os


class LaneVisualizer:
    """
    Menggambar semua overlay visualisasi pada frame.

    Konsep terintegrasi:
      - Overlay lane markers (polyline, polygon)
      - Denoising benchmark (NLM, bilateral, Gaussian, median) + PSNR
      - Template matching (marka jalan / zebra cross)
      - Contour fitting untuk segmentasi area jalur
    """

    # Warna BGR
    C_LEFT    = (50,  200,  50)    # hijau
    C_RIGHT   = (50,  200, 255)    # cyan
    C_CENTER  = (255, 180,   0)    # biru muda
    C_FILL    = (50,  200,  50)    # hijau transparan
    C_VP      = (0,     0, 255)    # merah (vanishing point)

    def __init__(self, alpha_fill=0.25):
        """
        Args:
            alpha_fill: Transparansi polygon fill (0.0 – 1.0)
        """
        self.alpha_fill = alpha_fill

    # ── Lane Overlay ──────────────────────────────────────────────────────────
    def draw_lane_line(self, frame, lane_coords, color, thickness=4):
        """
        Gambar satu garis jalur.

        Args:
            lane_coords: (x1, y1, x2, y2) atau None
        """
        if lane_coords is None:
            return frame
        x1, y1, x2, y2 = lane_coords
        cv2.line(frame, (x1, y1), (x2, y2), color, thickness)
        return frame

    def draw_lane_fill(self, frame, left_coords, right_coords):
        """
        Gambar polygon isi semi-transparan antara jalur kiri dan kanan.
        Area hijau = koridor aman kendaraan.
        """
        if left_coords is None or right_coords is None:
            return frame
        lx1, ly1, lx2, ly2 = left_coords
        rx1, ry1, rx2, ry2 = right_coords

        pts = np.array([[lx1, ly1], [lx2, ly2],
                        [rx2, ry2], [rx1, ry1]], dtype=np.int32)
        overlay = frame.copy()
        cv2.fillPoly(overlay, [pts], self.C_FILL)
        cv2.addWeighted(overlay, self.alpha_fill, frame, 1 - self.alpha_fill, 0, frame)
        return frame

    def draw_vanishing_point(self, frame, vp):
        """Gambar vanishing point dengan circle + crosshair."""
        if vp is None:
            return frame
        vx, vy = vp
        h, w = frame.shape[:2]
        if 0 <= vx < w and 0 <= vy < h:
            cv2.circle(frame, (vx, vy), 12, self.C_VP, -1)
            cv2.circle(frame, (vx, vy), 16, (255, 255, 255), 2)
            cv2.line(frame, (vx - 20, vy), (vx + 20, vy), (255, 255, 255), 1)
            cv2.line(frame, (vx, vy - 20), (vx, vy + 20), (255, 255, 255), 1)
        return frame

    # ── HUD Deviasi ───────────────────────────────────────────────────────────
    def draw_deviation_hud(self, frame, deviation_ratio, alert_level, alert_color,
                           x_left=None, x_right=None):
        """
        Gambar HUD (Heads-Up Display) informasi deviasi.

        Menampilkan:
          - Bar deviasi horizontal
          - Teks persentase deviasi
          - Alert level
        """
        h, w = frame.shape[:2]

        # ── Bar deviasi ──
        bar_w, bar_h = 300, 22
        bar_x = w // 2 - bar_w // 2
        bar_y = h - 60

        # Background bar
        cv2.rectangle(frame, (bar_x - 2, bar_y - 2),
                      (bar_x + bar_w + 2, bar_y + bar_h + 2), (0, 0, 0), -1)
        cv2.rectangle(frame, (bar_x, bar_y),
                      (bar_x + bar_w, bar_y + bar_h), (60, 60, 60), -1)

        # Posisi indicator
        center_x = bar_x + bar_w // 2
        ind_x    = int(center_x - deviation_ratio * (bar_w // 2))
        ind_x    = int(np.clip(ind_x, bar_x + 2, bar_x + bar_w - 2))
        cv2.rectangle(frame, (bar_x, bar_y),
                      (bar_x + bar_w, bar_y + bar_h), alert_color, -1)
        cv2.rectangle(frame, (center_x - 2, bar_y - 4),
                      (center_x + 2, bar_y + bar_h + 4), (255, 255, 255), -1)
        cv2.circle(frame, (ind_x, bar_y + bar_h // 2), 10, (255, 255, 255), -1)
        cv2.circle(frame, (ind_x, bar_y + bar_h // 2), 10, (0, 0, 0), 2)

        # Teks
        dev_pct = deviation_ratio * 100
        side    = 'KIRI' if dev_pct > 0 else 'KANAN'
        txt     = f"Deviasi: {abs(dev_pct):.1f}% {side}"
        cv2.putText(frame, txt, (bar_x, bar_y - 8),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.55, (255, 255, 255), 1, cv2.LINE_AA)

        # Alert level
        cv2.putText(frame, f"Status: {alert_level}", (bar_x, bar_y + bar_h + 20),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.55, alert_color, 2, cv2.LINE_AA)

        # Garis center kendaraan
        cv2.line(frame, (w//2, h-10), (w//2, h-80), (255, 255, 0), 1)

        return frame

    def draw_alert_banner(self, frame, alert_level, alert_color):
        """Gambar banner merah di atas frame saat bahaya."""
        if alert_level == 'DANGER':
            h, w = frame.shape[:2]
            overlay = frame.copy()
            cv2.rectangle(overlay, (0, 0), (w, 50), alert_color, -1)
            cv2.addWeighted(overlay, 0.6, frame, 0.4, 0, frame)
            cv2.putText(frame, "⚠  KELUAR JALUR — SEGERA KOREKSI  ⚠",
                        (w//2 - 210, 35), cv2.FONT_HERSHEY_DUPLEX,
                        0.75, (255, 255, 255), 2, cv2.LINE_AA)
        elif alert_level == 'MODERATE':
            h, w = frame.shape[:2]
            cv2.putText(frame, "PERINGATAN: Mendekati Batas Jalur",
                        (w//2 - 180, 35), cv2.FONT_HERSHEY_SIMPLEX,
                        0.7, alert_color, 2, cv2.LINE_AA)
        return frame

    def draw_info_panel(self, frame, info_dict):
        """Panel informasi tambahan di pojok kiri atas."""
        y = 25
        for key, val in info_dict.items():
            txt = f"{key}: {val}"
            cv2.putText(frame, txt, (10, y),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.5, (200, 200, 200), 1, cv2.LINE_AA)
            y += 22
        return frame

    # ── Denoising Benchmark ───────────────────────────────────────────────────
    def denoising_benchmark(self, frame, save_path=None):
        """
        Benchmark 4 metode denoising dengan PSNR.

        Konsep PSNR: 20·log10(255 / √MSE)
          Lebih tinggi = kualitas lebih baik (noise lebih sedikit).
          Digunakan untuk mengevaluasi efektivitas denoising secara objektif.

        Returns:
            results: dict {method: {'image': img, 'psnr': float}}
        """
        def psnr(orig, proc):
            mse = np.mean((orig.astype(np.float64) - proc.astype(np.float64))**2)
            return 20 * np.log10(255 / np.sqrt(mse + 1e-10))

        methods = {
            'NLM':        cv2.fastNlMeansDenoisingColored(frame, None, 10, 10, 7, 21),
            'Bilateral':  cv2.bilateralFilter(frame, 9, 75, 75),
            'Gaussian':   cv2.GaussianBlur(frame, (5, 5), 0),
            'Median':     cv2.medianBlur(frame, 5),
            'Original':   frame.copy(),
        }
        results = {m: {'image': img, 'psnr': psnr(frame, img)}
                   for m, img in methods.items()}

        print("\n  [Denoising Benchmark]")
        for m, r in results.items():
            print(f"    {m:<12}: PSNR = {r['psnr']:.2f} dB")

        if save_path:
            fig, axes = plt.subplots(1, len(results), figsize=(5*len(results), 4))
            for ax, (m, r) in zip(axes, results.items()):
                ax.imshow(cv2.cvtColor(r['image'], cv2.COLOR_BGR2RGB))
                ax.set_title(f"{m}\n{r['psnr']:.1f} dB", fontsize=9)
                ax.axis('off')
            plt.suptitle("Denoising Benchmark", fontsize=13, fontweight='bold')
            plt.tight_layout()
            os.makedirs(os.path.dirname(save_path) if os.path.dirname(save_path) else '.', exist_ok=True)
            plt.savefig(save_path, dpi=100, bbox_inches='tight')
            plt.show()
            print(f"  [INFO] Benchmark disimpan: {save_path}")
        return results

    # ── Template Matching ─────────────────────────────────────────────────────
    def detect_road_markings(self, frame, template=None):
        """
        Deteksi marka jalan (zebra cross / garis putus) via template matching.

        Konsep template matching (NCC):
          Geser template di atas gambar, hitung korelasi normalisasi.
          Lokasi korelasi maksimal = posisi marka yang cocok.

        Returns:
            (x, y, confidence) posisi dan keyakinan match
        """
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        if template is None:
            # Buat template marka jalan sintetis (garis putih horizontal)
            template = np.zeros((20, 60), dtype=np.uint8)
            cv2.rectangle(template, (0, 5), (59, 14), 200, -1)

        h_t, w_t = template.shape[:2]
        if gray.shape[0] < h_t or gray.shape[1] < w_t:
            return (0, 0, 0.0)

        res = cv2.matchTemplate(gray, template, cv2.TM_CCOEFF_NORMED)
        _, max_val, _, max_loc = cv2.minMaxLoc(res)
        return (*max_loc, float(max_val))

    # ── Contour fitting segmentasi jalur ─────────────────────────────────────
    def segment_road_area(self, frame, left_coords, right_coords):
        """
        Segmentasi area jalur menggunakan contour fitting.

        Konsep contour fitting:
          1. Buat mask polygon dari jalur kiri + kanan
          2. findContours untuk mendapat batas area jalur
          3. approxPolyDP untuk penyederhanaan kontur

        Returns:
            mask: binary mask area jalur
            contour: kontur jalur yang disederhanakan
        """
        h, w = frame.shape[:2]
        mask = np.zeros((h, w), dtype=np.uint8)

        if left_coords is None or right_coords is None:
            return mask, None

        lx1, ly1, lx2, ly2 = left_coords
        rx1, ry1, rx2, ry2 = right_coords

        pts = np.array([[lx1, ly1], [lx2, ly2],
                        [rx2, ry2], [rx1, ry1]], dtype=np.int32)
        cv2.fillPoly(mask, [pts], 255)

        # Contour fitting
        contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        if not contours:
            return mask, None
        cnt = max(contours, key=cv2.contourArea)
        approx = cv2.approxPolyDP(cnt, 0.02 * cv2.arcLength(cnt, True), True)
        return mask, approx

    # ── Full frame render ─────────────────────────────────────────────────────
    def render(self, frame, detection, deviation_ratio, alert_level,
               alert_color, lane_top_y, extra_info=None):
        """
        Render semua overlay pada satu frame.

        Args:
            frame          : Frame BGR asli
            detection      : Dict output LaneDetector.detect()
            deviation_ratio: Float [-1, 1]
            alert_level    : Str level alert
            alert_color    : BGR tuple warna alert
            lane_top_y     : y atas garis jalur (ROI top)
            extra_info     : Dict info tambahan untuk panel

        Returns:
            rendered: frame dengan semua overlay
        """
        rendered = frame.copy()
        h, w = rendered.shape[:2]
        y_bot = h - 1
        ld = detection

        # Extrapolasi koordinat jalur
        def ext(si, yb, yt):
            if si is None: return None
            s, i = si
            if abs(s) < 1e-6: return None
            try:
                x1 = int((yb - i) / s)
                x2 = int((yt - i) / s)
                return (x1, int(yb), x2, int(yt))
            except: return None

        left_c  = ext(ld.get('left_wls'),  y_bot, lane_top_y)
        right_c = ext(ld.get('right_wls'), y_bot, lane_top_y)

        # Lane fill
        self.draw_lane_fill(rendered, left_c, right_c)
        # Lane lines
        self.draw_lane_line(rendered, left_c,  self.C_LEFT,  thickness=5)
        self.draw_lane_line(rendered, right_c, self.C_RIGHT, thickness=5)
        # Vanishing point
        self.draw_vanishing_point(rendered, ld.get('vanishing_pt'))
        # HUD
        self.draw_deviation_hud(rendered, deviation_ratio, alert_level, alert_color)
        # Alert banner
        self.draw_alert_banner(rendered, alert_level, alert_color)
        # Info panel
        if extra_info:
            self.draw_info_panel(rendered, extra_info)

        return rendered
