"""
preprocessor.py
Konsep: Preprocessing (Gaussian blur, CLAHE), Edge Detection (Canny),
        ROI masking, OLS line fitting.

Langkah:
  1. Resize & grayscale
  2. CLAHE contrast enhancement
  3. Gaussian blur (noise reduction)
  4. Canny edge detection
  5. ROI trapezoid mask (hanya area jalan di depan)
  6. OLS line fitting untuk memperhalus deteksi
"""

import cv2
import numpy as np


class Preprocessor:
    """
    Preprocessing frame untuk deteksi jalur.

    Konsep terintegrasi:
      - Preprocessing (CLAHE, Gaussian blur)
      - Edge Detection (Canny)
      - ROI masking (trapezoid)
      - OLS (Ordinary Least Squares) line fitting
    """

    def __init__(self, blur_ksize=5, canny_lo=50, canny_hi=150,
                 roi_top_ratio=0.55, clahe_clip=2.0):
        """
        Args:
            blur_ksize    : Ukuran kernel Gaussian blur
            canny_lo/hi   : Threshold Canny
            roi_top_ratio : Batas atas ROI (rasio dari tinggi gambar)
            clahe_clip    : Clip limit CLAHE
        """
        self.blur_ksize    = blur_ksize
        self.canny_lo      = canny_lo
        self.canny_hi      = canny_hi
        self.roi_top_ratio = roi_top_ratio
        self.clahe         = cv2.createCLAHE(clipLimit=clahe_clip, tileGridSize=(8, 8))

    # ── Preprocessing ─────────────────────────────────────────────────────────
    def to_gray_enhanced(self, frame):
        """
        Grayscale + CLAHE untuk meningkatkan kontras garis jalur.
        Konsep: CLAHE (Contrast Limited Adaptive Histogram Equalization)
                menyesuaikan kontras secara lokal per tile.
        """
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        return self.clahe.apply(gray)

    def apply_blur(self, gray):
        """Gaussian blur untuk meredam noise sebelum deteksi tepi."""
        return cv2.GaussianBlur(gray, (self.blur_ksize, self.blur_ksize), 0)

    def detect_edges(self, blurred):
        """Canny edge detection."""
        return cv2.Canny(blurred, self.canny_lo, self.canny_hi)

    # ── ROI Mask ──────────────────────────────────────────────────────────────
    def make_roi_mask(self, shape):
        """
        Buat mask trapezoid untuk ROI (Region of Interest).
        Hanya area jalan di depan kendaraan yang diproses.

        ROI trapezoid: bagian bawah lebar, bagian atas sempit
        seperti sudut pandang kamera dashcam.

        Args:
            shape: (h, w) frame

        Returns:
            mask: binary mask (255 = area aktif)
        """
        h, w = shape[:2]
        top_y   = int(h * self.roi_top_ratio)
        top_w   = int(w * 0.10)   # Lebar atas ROI (10% dari lebar)
        bot_w   = int(w * 0.05)   # Margin bawah kiri/kanan

        polygon = np.array([[
            (bot_w,         h),
            (w - bot_w,     h),
            (w//2 + top_w,  top_y),
            (w//2 - top_w,  top_y),
        ]], dtype=np.int32)

        mask = np.zeros((h, w), dtype=np.uint8)
        cv2.fillPoly(mask, polygon, 255)
        return mask

    def apply_roi(self, edges, mask):
        """Terapkan mask ROI pada edge map."""
        return cv2.bitwise_and(edges, edges, mask=mask)

    # ── OLS Line Fitting ──────────────────────────────────────────────────────
    def fit_line_ols(self, points):
        """
        Ordinary Least Squares: β = (X'X)^-1 X'y
        Fitting garis y = ax + b dari kumpulan titik.

        Konsep OLS: meminimalkan Σ(yᵢ - ŷᵢ)² secara analitik
        menggunakan solusi normal equation.

        Args:
            points: array Nx2 [x, y]

        Returns:
            (slope, intercept) atau None
        """
        if len(points) < 2:
            return None
        x = points[:, 0].astype(np.float64)
        y = points[:, 1].astype(np.float64)
        X = np.column_stack([x, np.ones_like(x)])
        try:
            beta, _, _, _ = np.linalg.lstsq(X, y, rcond=None)
            return beta[0], beta[1]  # slope, intercept
        except np.linalg.LinAlgError:
            return None

    # ── Pipeline lengkap ──────────────────────────────────────────────────────
    def process(self, frame):
        """
        Jalankan pipeline preprocessing lengkap.

        Returns:
            dict {step_name: image}
        """
        gray     = self.to_gray_enhanced(frame)
        blurred  = self.apply_blur(gray)
        edges    = self.detect_edges(blurred)
        mask     = self.make_roi_mask(frame.shape)
        roi_edge = self.apply_roi(edges, mask)

        # Overlay ROI pada frame asli untuk visualisasi
        roi_vis = frame.copy()
        roi_contour = np.array([[
            (int(frame.shape[1]*0.05),          frame.shape[0]),
            (int(frame.shape[1]*0.95),          frame.shape[0]),
            (int(frame.shape[1]//2 + frame.shape[1]*0.10), int(frame.shape[0]*self.roi_top_ratio)),
            (int(frame.shape[1]//2 - frame.shape[1]*0.10), int(frame.shape[0]*self.roi_top_ratio)),
        ]], dtype=np.int32)
        cv2.polylines(roi_vis, roi_contour, True, (0, 200, 255), 2)

        return {
            '1. Original':       frame,
            '2. CLAHE Gray':     gray,
            '3. Gaussian Blur':  blurred,
            '4. Canny Edges':    edges,
            '5. ROI Area':       roi_vis,
            '6. ROI Edges':      roi_edge,
        }
