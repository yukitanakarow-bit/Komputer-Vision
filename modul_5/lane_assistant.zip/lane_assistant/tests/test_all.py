"""
tests/test_all.py — Unit test untuk semua modul Lane Keeping Assistant.
Jalankan: python tests/test_all.py  atau  python -m pytest tests/ -v
"""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import cv2, numpy as np


def make_road(w=640, h=360):
    """Gambar jalan sintetis sederhana."""
    img = np.ones((h, w, 3), dtype=np.uint8) * 70
    # Jalur kiri (putih)
    cv2.line(img, (w//4, h-1),   (w//2 - 20, int(h*0.5)), (200,200,200), 3)
    # Jalur kanan (putih)
    cv2.line(img, (3*w//4, h-1), (w//2 + 20, int(h*0.5)), (200,200,200), 3)
    return img

# ── Preprocessor ─────────────────────────────────────────────────────────────
def test_preprocess():
    from preprocessor import Preprocessor
    pp = Preprocessor()
    img = make_road()
    steps = pp.process(img)
    assert len(steps) == 6
    assert list(steps.values())[-1].shape[:2] == img.shape[:2]
    print("[PASS] test_preprocess")

def test_ols_fit():
    from preprocessor import Preprocessor
    pp = Preprocessor()
    pts = np.array([[0,0],[1,2],[2,4],[3,6]], dtype=np.float32)
    a, b = pp.fit_line_ols(pts)
    assert abs(a - 2.0) < 0.1 and abs(b) < 0.3
    print("[PASS] test_ols_fit")

def test_roi_mask():
    from preprocessor import Preprocessor
    pp = Preprocessor()
    mask = pp.make_roi_mask((360, 640))
    assert mask.shape == (360, 640)
    assert mask.max() == 255 and mask.min() == 0
    print("[PASS] test_roi_mask")

# ── LaneDetector ─────────────────────────────────────────────────────────────
def test_hough_lines():
    from lane_detector import LaneDetector
    ld = LaneDetector(hough_threshold=20, min_line_length=20)
    img = make_road()
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    edges = cv2.Canny(gray, 50, 150)
    lines = ld.detect_hough_lines(edges)
    assert isinstance(lines, np.ndarray)
    print(f"[PASS] test_hough_lines ({len(lines)} lines)")

def test_classify_lines():
    from lane_detector import LaneDetector
    ld = LaneDetector()
    # Buat garis kiri (slope negatif, x < center) dan kanan (slope positif, x > center)
    lines = np.array([
        [100, 300, 280, 200],   # kiri
        [400, 300, 540, 200],   # kanan
    ])
    left, right = ld.classify_lines(lines, frame_width=640)
    assert len(left) >= 1 and len(right) >= 1
    print("[PASS] test_classify_lines")

def test_ransac_lane():
    from lane_detector import LaneDetector
    ld = LaneDetector()
    lines = np.array([[100,300,200,250],[110,310,210,255],[300,300,400,250]])
    result = ld.ransac_select_lane(lines)
    assert result is not None and len(result) == 2
    print("[PASS] test_ransac_lane")

def test_wls_lane():
    from lane_detector import LaneDetector
    ld = LaneDetector()
    lines = np.array([[100,300,200,250],[110,310,210,255]])
    result = ld.wls_average_lane(lines)
    assert result is not None and len(result) == 2
    print("[PASS] test_wls_lane")

def test_vanishing_point():
    from lane_detector import LaneDetector
    ld = LaneDetector()
    # Jalur kiri: slope -0.5, intercept 350 → kanan: slope 0.5, intercept 50
    left  = (-0.5, 350.0)
    right = ( 0.5,  50.0)
    vp = ld.estimate_vanishing_point(left, right)
    assert vp is not None
    vx, vy = vp
    assert abs(vx - 300) < 20   # seharusnya sekitar x=300
    print(f"[PASS] test_vanishing_point ({vx}, {vy})")

# ── DeviationAnalyzer ─────────────────────────────────────────────────────────
def test_deviation_center():
    from deviation_analyzer import DeviationAnalyzer
    da = DeviationAnalyzer()
    left  = (-0.5, 350.0)
    right = ( 0.5,  50.0)
    dev_px, dev_ratio, xl, xr = da.compute_deviation(left, right, (360, 640))
    assert abs(dev_ratio) < 0.15, f"Simetris → deviasi kecil, dapat {dev_ratio:.3f}"
    print(f"[PASS] test_deviation_center (dev={dev_ratio*100:.1f}%)")

def test_deviation_left():
    from deviation_analyzer import DeviationAnalyzer
    da = DeviationAnalyzer()
    # Jalur lebih ke kanan → kendaraan ke kiri
    left  = (-0.6, 450.0)
    right = ( 0.6,  10.0)
    _, dev_ratio, _, _ = da.compute_deviation(left, right, (360, 640))
    print(f"[PASS] test_deviation_left (dev={dev_ratio*100:.1f}%)")

def test_alert_levels():
    from deviation_analyzer import DeviationAnalyzer
    da = DeviationAnalyzer()
    assert da.get_alert_level(0.02)[0] == 'OK'
    assert da.get_alert_level(0.08)[0] == 'MILD'
    assert da.get_alert_level(0.15)[0] == 'MODERATE'
    assert da.get_alert_level(0.25)[0] == 'DANGER'
    print("[PASS] test_alert_levels")

def test_tls_centerline():
    from deviation_analyzer import DeviationAnalyzer
    da = DeviationAnalyzer()
    left  = (-0.5, 350.0)
    right = ( 0.5,  50.0)
    result = da.tls_fit_centerline(left, right, (360, 640))
    assert result is not None
    print(f"[PASS] test_tls_centerline (slope={result[0]:.3f})")

def test_ridge_smoothing():
    from deviation_analyzer import DeviationAnalyzer
    da = DeviationAnalyzer()
    devs = [0.1*np.sin(i*0.3) + np.random.normal(0, 0.05) for i in range(30)]
    smoothed = da.smooth_trajectory_ridge(devs)
    assert len(smoothed) == len(devs)
    print("[PASS] test_ridge_smoothing")

def test_lasso_smoothing():
    from deviation_analyzer import DeviationAnalyzer
    da = DeviationAnalyzer()
    devs = [0.05*i/30 + np.random.normal(0, 0.03) for i in range(30)]
    smoothed = da.smooth_trajectory_lasso(devs)
    assert len(smoothed) == len(devs)
    print("[PASS] test_lasso_smoothing")

def test_kfold_cv():
    from deviation_analyzer import DeviationAnalyzer
    da = DeviationAnalyzer()
    devs = [0.1*np.sin(i*0.3) for i in range(40)]
    results = da.evaluate_smoothing_cv(devs, k=4)
    assert 'Ridge (L2)' in results and 'Lasso (L1)' in results
    print("[PASS] test_kfold_cv")

# ── FittingComparator ─────────────────────────────────────────────────────────
def test_fitting_methods():
    from fitting_comparator import FittingComparator
    fc = FittingComparator()
    np.random.seed(0)
    x = np.linspace(0, 100, 60)
    y = 2.5 * x + 30 + np.random.normal(0, 10, 60)
    # Tambah outlier
    x = np.concatenate([x, [20, 60, 80]])
    y = np.concatenate([y, [500, -100, 600]])

    ols  = fc.ols(x, y)
    wls  = fc.wls(x, y)
    tls  = fc.tls(x, y)
    rans = fc.ransac(x, y)

    # RANSAC harus slope lebih dekat ke 2.5
    assert abs(rans[0] - 2.5) < abs(ols[0] - 2.5) + 0.5
    print(f"[PASS] test_fitting_methods (RANSAC={rans[0]:.2f}, true=2.5)")

# ── Full Pipeline ─────────────────────────────────────────────────────────────
def test_full_pipeline():
    from lane_pipeline import LaneAssistantPipeline
    cfg = {'results_dir': '/tmp/test_lane', 'hough_threshold': 15, 'min_line_length': 20}
    pipeline = LaneAssistantPipeline(config=cfg)
    img = make_road()
    result = pipeline.process_frame(img)
    assert 'rendered' in result and result['rendered'] is not None
    assert 'dev_ratio' in result and -1 <= result['dev_ratio'] <= 1
    assert 'alert_level' in result
    print(f"[PASS] test_full_pipeline (alert={result['alert_level']}, dev={result['dev_ratio']*100:.1f}%)")

def test_template_matching():
    from visualizer import LaneVisualizer
    viz = LaneVisualizer()
    img = make_road()
    x, y, conf = viz.detect_road_markings(img)
    assert 0.0 <= conf <= 1.0
    print(f"[PASS] test_template_matching (conf={conf:.3f})")

def test_denoising():
    from visualizer import LaneVisualizer
    viz = LaneVisualizer()
    img = make_road()
    results = viz.denoising_benchmark(img)
    for m in ['NLM','Bilateral','Gaussian','Median']:
        assert m in results and results[m]['psnr'] > 0
    print("[PASS] test_denoising")

# ── Runner ────────────────────────────────────────────────────────────────────
if __name__ == '__main__':
    print("\n" + "="*60)
    print("  Unit Tests — Lane Keeping Assistant Simulator")
    print("="*60 + "\n")
    tests = [
        test_preprocess, test_ols_fit, test_roi_mask,
        test_hough_lines, test_classify_lines, test_ransac_lane,
        test_wls_lane, test_vanishing_point,
        test_deviation_center, test_deviation_left, test_alert_levels,
        test_tls_centerline, test_ridge_smoothing, test_lasso_smoothing,
        test_kfold_cv, test_fitting_methods,
        test_full_pipeline, test_template_matching, test_denoising,
    ]
    passed = failed = 0
    for t in tests:
        try:
            t(); passed += 1
        except Exception as e:
            print(f"[FAIL] {t.__name__}: {e}"); failed += 1
    print(f"\n{'='*60}")
    print(f"  {passed} PASSED  |  {failed} FAILED")
    print("="*60)
